---
name: Timeless Elegance System
colors:
  surface: '#f9f9f6'
  surface-dim: '#dadad7'
  surface-bright: '#f9f9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f0'
  surface-container: '#eeeeeb'
  surface-container-high: '#e8e8e5'
  surface-container-highest: '#e2e3df'
  on-surface: '#1a1c1a'
  on-surface-variant: '#50453b'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f1f1ee'
  outline: '#82756a'
  outline-variant: '#d4c4b7'
  surface-tint: '#7d562d'
  primary: '#7d562d'
  on-primary: '#ffffff'
  primary-container: '#d4a373'
  on-primary-container: '#5b3912'
  inverse-primary: '#f0bd8b'
  secondary: '#645e4b'
  on-secondary: '#ffffff'
  secondary-container: '#ece2c9'
  on-secondary-container: '#6b6450'
  tertiary: '#6a5b53'
  on-tertiary: '#ffffff'
  tertiary-container: '#bba99f'
  on-tertiary-container: '#4b3e36'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcbd'
  primary-fixed-dim: '#f0bd8b'
  on-primary-fixed: '#2c1600'
  on-primary-fixed-variant: '#623f18'
  secondary-fixed: '#ece2c9'
  secondary-fixed-dim: '#cfc6ae'
  on-secondary-fixed: '#201b0c'
  on-secondary-fixed-variant: '#4c4634'
  tertiary-fixed: '#f3dfd3'
  tertiary-fixed-dim: '#d6c3b8'
  on-tertiary-fixed: '#241913'
  on-tertiary-fixed-variant: '#51443c'
  background: '#f9f9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e2e3df'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Montserrat
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1200px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style

The brand identity centers on the transition from traditional luxury to modern, approachable wellness. It targets a discerning clientele seeking expert-led beauty services, evoking feelings of serenity, trust, and refined self-care.

The design style is **Minimalist-Premium**, characterized by:
- **Quiet Luxury:** High use of negative space to allow visual elements to breathe.
- **Organic Professionalism:** A balance between the structured authority of a 20-year career and the soft, feminine touch of a boutique salon.
- **Tactile Accents:** Subtle use of gold and soft rose to create focal points without overwhelming the neutral base.

## Colors

The palette is rooted in warmth and skin-toned neutrals to reflect the beauty industry. 

- **Primary (Warm Nude):** Used for primary actions, active states, and key brand elements.
- **Secondary (Champagne Beige):** The workhorse for surface areas and container backgrounds.
- **Tertiary (Soft Rose):** Used sparingly for subtle highlights, notification badges, or decorative icons.
- **Neutral (Dark Charcoal):** High-contrast text color to ensure legibility and a professional edge.
- **Background (Ivory):** The primary canvas color, softer and more premium than pure white.
- **Accent (Gold):** Reserved for thin borders, iconography details, and "Premium" service tier indicators.

## Typography

The typographic hierarchy relies on the tension between the editorial **Playfair Display** and the geometric **Montserrat**. 

- **Headlines:** Use Playfair Display for all headings (H1-H3). Large display text should use tighter letter spacing for a more sophisticated look.
- **Body Text:** Use Montserrat for all long-form content, descriptions, and UI labels. 
- **Language Nuance:** Since the content is in Portuguese (PT-PT), ensure line-heights accommodate accented characters (á, à, õ, ç) without clipping.
- **Styling:** Use uppercase labels with slight letter spacing for "Service Categories" or "Category Tags" to enhance the premium aesthetic.

## Layout & Spacing

The layout follows a **Fluid Grid** model with generous margins to evoke a sense of exclusivity and space.

- **Grid:** Use a 12-column grid for desktop and a 4-column grid for mobile.
- **Rhythm:** An 8px base unit drives all spacing decisions.
- **Sectioning:** Vertical gaps between major landing page sections should be significant (120px+) to maintain the "spacious" requirement.
- **Alignment:** Content is generally center-aligned for the name and intro, but switches to left-aligned for service lists and booking forms for better readability.

## Elevation & Depth

Visual hierarchy is established through soft, organic depth rather than harsh shadows.

- **Tonal Layering:** Most depth is created by placing Ivory containers on Champagne Beige backgrounds.
- **Shadows:** Use extremely diffused shadows for floating elements like "Book Now" buttons or service cards. 
  - *Character:* `0px 12px 32px rgba(51, 53, 51, 0.04)`.
- **Transitions:** All hover states and view transitions must be smooth (300ms, ease-out) to match the calm, professional atmosphere of the salon.

## Shapes

The shape language is soft and approachable, avoiding aggressive sharp corners.

- **Cards & Inputs:** Use the `rounded-lg` (16px) setting for main service cards and booking containers.
- **Buttons:** Primary buttons should use `rounded-xl` (24px) or fully pill-shaped styles to feel comfortable and inviting.
- **Decorative Elements:** Use circular frames for "Before & After" photos or staff portraits to emphasize the "warm and feminine" narrative.

## Components

### Buttons
- **Primary:** Warm Nude (#D4A373) background with Ivory text. Pill-shaped. Subtle lift on hover.
- **Secondary:** Gold (#D4AF37) 1px outline with Dark Charcoal text. No background fill.

### Cards
- **Service Cards:** Ivory background, 16px corner radius, soft 4% opacity shadow. Headers in Playfair Display.
- **Testimonial Cards:** Soft Rose (#E9D5CA) light background with italicized Playfair Display typography.

### Input Fields
- **Booking Form:** Minimalist style. No background fill, 1px bottom border in Champagne Beige. Focus state shifts the border to Gold.

### Chips & Tags
- **Category Tags:** Champagne Beige background with uppercase Montserrat labels. High roundedness.

### Specialty Components
- **Service List:** Interactive lists where the background subtly shifts to Soft Rose on hover.
- **Booking Footer:** A fixed-position bar on mobile containing a "Marcar Agora" (Book Now) button in Warm Nude.